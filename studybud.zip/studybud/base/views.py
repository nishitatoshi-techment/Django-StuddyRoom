from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required

from studybud import settings
from . models import Message, Room, Topic
from .forms import RoomForm, UserForm, SignupForm
from django.db.models import Q
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from .forms import SignupForm  
from django.contrib.sites.shortcuts import get_current_site  
from django.utils.encoding import force_bytes, force_str
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode  
from django.template.loader import render_to_string  
from .token import account_activation_token 
from django.contrib.auth.models import User  
# from django.core.mail import EmailMessage  
from django.contrib.auth import get_user_model
from django.core.mail import send_mail


# from django.contrib.auth.forms import UserCreationForm
# from .forms import CustomUserCreationForm  


    # Create your views here.

    # rooms =[
    #     {'id':1, 'name':'Lets learn python'},
    #     {'id':2, 'name':'Design with me'},
    #     {'id':3, 'name':'Frontend developers'},

    # ]

def loginPage(request):

        page = 'login'

        if request.user.is_authenticated:
            return redirect('home')

        if request.method == 'POST':
            username = request.POST.get('username').lower()
            password = request.POST.get('password')

            try:
                user = User.objects.get(username=username)

            except:
                messages.error(request, 'User does not exist')

            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                return redirect('home')

            else:
                messages.error(request, 'Username  or password does not exist')

        context={'page': page}
        return render(request, 'base/login_register.html', context)

def logoutUser(request):
        logout(request)
        return redirect('home')

def registerPage(request):
        # page = 'register'
        # form = UserCreationForm()
        form = SignupForm(request.POST or None)


        # if request.method == 'POST':
        if form.is_valid():
                print('if stmnt')
                user = form.save(commit=False)
                # in above code we froze the registration data to check first if they accidentely made any mistake, like uppercase instead of lowercase.
                user.username = user.username.lower()
                user.save()

                # to get the domain of the current site  
                current_site = get_current_site(request)  
                mail_subject = 'Activation link has been sent to your email id'  
                message = render_to_string('acc_active_email.html', {  
                    'user': user,  
                    'domain': current_site.domain,  
                    'uid':urlsafe_base64_encode(force_bytes(user.pk)),  
                    'token':account_activation_token.make_token(user),  
                })  
                to_email = form.cleaned_data.get('email')
                from_email = settings.EMAIL_HOST_USER
                print('doaihio')

                send_mail(user.username , "Your account has created",
                  "nishita.toshi@techment.com", [to_email], fail_silently=False)
  
                # send_mail(  
                #             mail_subject, message, from_email , [to_email], fail_silently=False,
                # )  
                # email.send()  
                login(request, user)

                return HttpResponse('Please confirm your email address to complete the registration')
                # return redirect('home')
        else:
            print('else')
            if request.method == 'POST':

                # print('sdbbb')
                # form = SignupForm()  
                # # return render(request, 'signup.html', {'form': form})  
                # # messages.error(request, 'an error occurred during registration')

                # return render(request, 'base/login_register.html' , {'form':form})

                username = request.POST['username']
                email = request.POST['email']
              
                pass1 = request.POST['password1']
                pass2 = request.POST['password2']

                user = User.objects.create_user(username, email, pass1)


                
                # in above code we froze the registration data to check first if they accidentely made any mistake, like uppercase instead of lowercase.
                # user.username = user.username.lower()
                # user.first_name = 'fname'
                # user.last_name = 'lname'
                user.save()

                send_mail(username , "Your account has created",
                  "nishita.toshi@techment.com", [email], fail_silently=False)

                # to get the domain of the current site  
                # current_site = get_current_site(request)  
                # mail_subject = 'Activation link has been sent to your email id'  
                # message = render_to_string('acc_active_email.html', {  
                #     'user': user,  
                #     # 'domain': current_site.domain,  
                #     'uid':urlsafe_base64_encode(force_bytes(user.pk)),  
                #     'token':account_activation_token.make_token(user),  
                # })  
                # to_email = form.cleaned_data.get('email')
                # from_email = settings.EMAIL_HOST_USER
                # print('doaihio')

                # send_mail(user.username , "Your account has created",
                #   "nishita.toshi@techment.com", [email])
  
                # send_mail(  
                #             mail_subject, message, from_email , [to_email], fail_silently=False,
                # )  
                # email.send()  
                login(request, user)

                return HttpResponse('Please confirm your email address to complete the registration')
                # return redirect('home')
            return render(request, 'base/login_register.html' , {'form':form})


                

# activation link
def activate(request, uid, token):  
    User = get_user_model()  
    try:  
        uid = force_str(urlsafe_base64_decode(uid))  
        user = User.objects.get(pk=uid)  

    except(TypeError, ValueError, OverflowError, User.DoesNotExist):  
        user = None  
    if user is not None and account_activation_token.check_token(user, token):  
        user.is_active = True  
        user.save()  
        
        return HttpResponse('Thank you for your email confirmation. Now you can login your account.')  
    else:  
        return HttpResponse('Activation link is invalid!')

def home(request):

        # Search Functionality
        q = request.GET.get('q') if request.GET.get('q') != None else ''

        rooms = Room.objects.filter(
            Q(topic__name__icontains=q) | 
            Q(name__icontains=q) | 
            Q(description__icontains=q)
            )

        # icontains is not case sensitive and if we manually type the initials of what we are searching for it will work

        topics = Topic.objects.all()
        room_count = rooms.count()
        room_messages = Message.objects.filter(Q(room__topic__name__icontains=q))

        context = {'rooms': rooms, 'topics':topics, 'room_count':room_count, 'room_messages': room_messages}
        return render(request, 'base/home.html', context)

def room(request, pk):
        room = Room.objects.get(id=pk)
        room_messages = room.message_set.all().order_by()
        # MESSAGE model is used above but it should be in lower case with _set.all()
        participants = room.participants.all()
        if request.method == 'POST':
            message = Message.objects.create(
                user = request.user,
                room = room,
                body = request.POST.get('body'),
            )
            room.participants.add(request.user)
            return redirect('room', pk=room.id)
        # this if condition is used to add message to chat room 

        context = {'room': room, 'room_messages':room_messages, 'participants': participants}
        return render(request, 'base/room.html', context)

def userProfile(request, pk):
    user = User.objects.get(id=pk)
    rooms = user.room_set.all()
    room_messages = user.message_set.all()
    topics = Topic.objects.all()
    context = {'user':user, 'rooms':rooms,'room_messages':room_messages, 'topics':topics}
    return render(request, 'base/profile.html', context)

@login_required(login_url='login') 
def createRoom(request):
        form = RoomForm()
        topics = Topic.objects.all()
        if request.method == 'POST':
            topic_name = request.POST.get('topic')
            topic, created = Topic.objects.get_or_create(name=topic_name)

            Room.objects.create(
                host=request.user,
                topic = topic,
                name = request.POST.get('name'),
                description = request.POST.get('descrption'),
            )
            # form = RoomForm(request.POST)
            # if form.is_valid():
            #     room = form.save(commit=False)
            #     room.host = request.user
            #     room.save()
            return redirect('home')

        context={'form':form, 'topics':topics}
        return render(request, 'base/room_form.html', context)

@login_required(login_url='login')
def updateRoom(request, pk):
        room = Room.objects.get(id=pk)
        form = RoomForm(instance=room)
        topics = Topic.objects.all()


        # you can only edit your room
        if request.user != room.host:
            return HttpResponse('You are not allowed here!!')

        if request.method == 'POST':
            topic_name = request.POST.get('topic')
            topic, created = Topic.objects.get_or_create(name=topic_name)
            room.name = request.POST.get('name')
            room.topic = topic
            room.description = request.POST.get('description')

            room.save()

            return redirect('home')

        
        context ={'form':form, 'topics':topics, 'room':room}
        return render(request, 'base/room_form.html', context)

@login_required(login_url='login')
def deleteRoom(request, pk):
        room = Room.objects.get(id=pk)

        # you can only edit your room
        if request.user != room.host:
            return HttpResponse('You are not allowed here!!')

        
        if request.method == 'POST':
            room.delete()
            return redirect('home')

        return render(request, 'base/delete.html', {'obj':room})


@login_required(login_url='login')
def deleteMessage(request, pk):
        message = Message.objects.get(id=pk)

        # you can only edit your room
        if request.user != message.user:
            return HttpResponse('You are not allowed here!!')

        
        if request.method == 'POST':
            message.delete()
            return redirect('home')

        return render(request, 'base/delete.html', {'obj':message})

@login_required(login_url='login')
def updateUser(request):
    user = request.user
    form = UserForm(instance=user)

    if request.method == 'POST':
        form = UserForm(request.POST,instance=user)
        if form.is_valid():
            form.save()
            return redirect('user-profile', pk=user.id )

    return render(request, 'base/update-user.html', {'form':form})
